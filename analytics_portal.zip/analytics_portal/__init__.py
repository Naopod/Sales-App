# Analytics Portal Django Configuration
